module.exports = {

  database: process.env.DATABASE || 'mongodb://sinan:password@ds121622.mlab.com:21622/fiveer',
  port: process.env.PORT ||3005,
  secret: process.env.SECRET || 'zefgzeifiugefiguef6rgri',

}
